
def handler(event, context):
    """CSPM Lab Lambda — intentionally has admin role attached."""
    return {
        "statusCode": 200,
        "body": "CSPM Lab Lambda running"
    }
